pets = [
    {"animal": "Cachorro", "dono": "João"},
    {"animal": "Gato", "dono": "Maria"},
    {"animal": "Pássaro", "dono": "Pedro"}
]

for pet in pets:
    print("Animal:", pet["animal"])
    print("Dono:", pet["dono"])
    print()
