pessoa = {
    "first_name": "João",
    "last_name": "Silva",
    "age": 30,
    "city": "São Paulo"
}

print("Nome:", pessoa["first_name"])
print("Sobrenome:", pessoa["last_name"])
print("Idade:", pessoa["age"])
print("Cidade:", pessoa["city"])
